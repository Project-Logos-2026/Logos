# BioPraxis (subdomain of AnthroPraxis)
Purpose: biological grounding for human embodiment and life-process logic.
Status: v0.1 scaffold, zero admits.
