# AnthroPraxis (Anthropology)
Purpose: personhood, social roles, normed interaction.
Status: v0.1 scaffold, zero admits.
