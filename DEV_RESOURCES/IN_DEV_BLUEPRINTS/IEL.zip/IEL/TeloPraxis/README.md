# TeloPraxis

## Overview

This directory contains the TeloPraxis implementation within the Internal Emergent Logics (Integrated Experiential Logic) framework.

## Files

- `modules\Internal Emergent Logics\TeloPraxis\README.md`

## Development

This praxis is part of the LOGOS PXL Core system. See the main README for development setup.
