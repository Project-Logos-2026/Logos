[PASTE THE FULL CONTENTS OF THE PRIOR GPT MESSAGE HERE — user must provide the actual contract text for verbatim insertion.]
