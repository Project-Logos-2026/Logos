# NEXUS INTEGRATION CONTRACT (LANGUAGE)

## Interfaces
- Read-only access to SMP.
- Controlled access to fractal substrates.

## Isolation
- No cross-agent mutation.