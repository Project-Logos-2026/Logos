# FRACTAL LANGUAGE APPLICATION CONTRACT

## Constraints
- Fractals optimize form only.
- Meaning modification is forbidden.

## Termination
- Convergence required.