# LANGUAGE VALIDATION PLAN

## Tests
- Semantic Preservation
- Determinism
- Ablation